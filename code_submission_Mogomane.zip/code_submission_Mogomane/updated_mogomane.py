def display_menu() -> None:
    print("Choose an arithmetic operation:")
    print("1. Addition")
    print("2. Subtraction")
    print("3. Nominal Division")
    print("4. Floor Division")
    print("5. Modulo")
    print("6. Exponential")
    print("7. Multiplication")

def get_numbers() -> tuple[int, int]:
    while True:
        try:
            num1 = int(input("Enter the first integer number: "))
            num2 = int(input("Enter the second integer number: "))
            return num1, num2
        except ValueError:
            print("Invalid input. Please enter integer numbers.")

def addition(num1: int, num2: int) -> int:
    return num1 + num2

def subtraction(num1: int, num2: int) -> int:
    return num1 - num2

def nominal_division(num1: int, num2: int) -> float:
    try:
        return num1 / num2
    except ZeroDivisionError:
        print("Error: Division by zero is not allowed.")
        return None

def floor_division(num1: int, num2: int) -> int:
    try:
        return num1 // num2
    except ZeroDivisionError:
        print("Error: Division by zero is not allowed.")
        return None

def modulo(num1: int, num2: int) -> int:
    try:
        return num1 % num2
    except ZeroDivisionError:
        print("Error: Division by zero is not allowed.")
        return None

def exponential(num1: int, num2: int) -> int:
    return num1 ** num2

def multiplication(num1: int, num2: int) -> int:
    return num1 * num2

def perform_operation(choice: int, num1: int, num2: int, operation_callback) -> float:
    result = operation_callback(num1, num2)
    return result

def is_odd(number: float) -> bool:
    return number % 2 != 0

def main() -> None:
    while True:
        display_menu()
        try:
            choice = int(input("Enter your choice (1-7): "))
            if choice < 1 or choice > 7:
                print("Invalid choice. Please select a number between 1 and 7.")
                continue
        except ValueError:
            print("Invalid input. Please enter a number between 1 and 7.")
            continue
        
        num1, num2 = get_numbers()
        
        operation_callbacks = {
            1: addition,
            2: subtraction,
            3: nominal_division,
            4: floor_division,
            5: modulo,
            6: exponential,
            7: multiplication
        }
        
        operation_names = {
            1: "Addition",
            2: "Subtraction",
            3: "Nominal Division",
            4: "Floor Division",
            5: "Modulo",
            6: "Exponential",
            7: "Multiplication"
        }

        operation_callback = operation_callbacks.get(choice)
        operation_name = operation_names.get(choice, "Unknown Operation")

        result = perform_operation(choice, num1, num2, operation_callback)

        if result is not None:
            print(f"\nThe two numbers you entered are: {num1} and {num2}")
            print(f"The result of your {operation_name} operation is: {result}")
            if is_odd(result):
                print("The result of your arithmetic operation is odd.")
            else:
                print("The result of your arithmetic operation is even.")
        else:
            print("There was an error performing the operation.")
        
        another = input("Do you want to perform another operation? (yes/no): ").strip().lower()
        if another != 'yes':
            print("Thank you for using the arithmetic operation program. Goodbye!")
            break

if __name__ == "__main__":
    main()
